
<?php
//http://blog.teamtreehouse.com/an-introduction-to-websockets
//http://www.sanwebe.com/2013/05/chat-using-websocket-php-socket
/*
1.what is websocket location and $host is it really needed for connection in the handshake 

*/

$host = 'localhost'; //host
$port = '9000'; //port
$null = NULL; //null var

//Create TCP/IP sream socket
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP); 
// DOMAIN : AF_INET = ipv4 , AF_INET = ipv6 and .....
// TYPE : SOCK_STREAM = TCP , SOCK_DGRAM = UDP and ...
// PROTOCOL : SOL_TCP = for tcp , SOL_UDP = for udp as above

//reuseable port
socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
// valid socket ( check with is_resource($socket) )
// level
// here comes option = in this context reuseable
// value of above line option 

//bind socket to specified host
socket_bind($socket, 0, $port);
// valid socket
// $address dotted-quad notation (e.g. 127.0.0.1). 
// $port only required for tcp 

//listen to port
socket_listen($socket);
// i think server socket types that are valid resource can listen to incoming connections 
// socket_listen() is applicable only to sockets of type SOCK_STREAM or SOCK_SEQPACKET

//create & add listning socket to the list
$clients = array($socket);
// array with one element the listening socket itself is created 
// check with var_dump( $socket ); variable dump prints all types of variables

//----------------------------------------------------------------------------------------------------
// create , set , bind , listen , array , CSBLA , ( Hint : CESBOLA )
//----------------------------------------------------------------------------------------------------

//start endless loop, so that our script doesn't stop
while (true) {
	//manage multipal connections
	$changed = $clients;
	
	//returns the socket resources in $changed array
	socket_select($changed, $null, $null, 0, 10);
	// read sockets are watched for EOL in their read streams
	// write sockets are watched in parameter2 
	// exception sockets are watched in parameter3
	// tv_sec = timeout seconds
	// tv_usec = microseconds timeout
	
	
	//check for new socket
	if (in_array($socket, $changed)) { 
		// i will check if server is readable after socket_select and in $changed array ....
		// so server got a message 		
		
		$socket_new = socket_accept($socket); //accpet new socket
		// my understanding : if socket_accept is used without checking the socket_select for readable , then we end up in blocked program
		
		$clients[] = $socket_new; //add socket to client array
		// MyU : another way of pushing into array is array_push( array_name , value ) 
				
		$header = socket_read($socket_new, 1024); //read data sent by the socket
		// $remote sockets header is read upto maximum of 1024 bytes 
		// the header must have enough handshaking data in that 1024 bytes
		
		perform_handshaking($header, $socket_new, $host, $port); //perform websocket handshake		
		// my understanding is : see method for clear docs 
		
		socket_getpeername($socket_new, $ip); //get ip address of connected socket
		// $remote ip and if specified ( $remotesocket , $ip , $port_number ) ;
		
		$response = mask(json_encode(array('type'=>'system', 'message'=>$ip.' connected'))); //prepare json data
		// string(40) "{"type":"system","message":" connected"}" , after json encoding ...i removed $ip 
        // my understanding is : see method for clear docs 		
		
		send_message($response); //notify all users about new connection
		// my understanding is : see method for clear docs 
		
		
		$found_socket = array_search($socket, $changed);
		// $found_socket will contain the index of $socket found in $changed array
		unset($changed[$found_socket]);
		// this will unset ( remove ) the server socket from the list of $changed sockets 
	}
	
	//loop through all connected sockets
	foreach ($changed as $changed_socket) {	
		
		//check for any incomming data
		while(socket_recv($changed_socket, $buf, 1024, 0) >= 1)
		{
			$received_text = unmask($buf); //unmask data
			$tst_msg = json_decode($received_text); //json decode 
			$user_name = $tst_msg->name; //sender name
			$user_message = $tst_msg->message; //message text
			$user_color = $tst_msg->color; //color
			
			//prepare data to be sent to client
			$response_text = mask(json_encode(array('type'=>'usermsg', 'name'=>$user_name, 'message'=>$user_message, 'color'=>$user_color)));
			
			send_message($response_text); //send data
			
			break 2; //exist this loop
			// break 2 means exit this loop and another loop ahead of it 
			// break 3 is break 3 loops from now 
		}
		
		$buf = @socket_read($changed_socket, 1024, PHP_NORMAL_READ);
		if ($buf === false) { // check disconnected client
			// remove client for $clients array
			$found_socket = array_search($changed_socket, $clients);
			socket_getpeername($changed_socket, $ip);
			unset($clients[$found_socket]);
			
			//notify all users about disconnected connection
			$response = mask(json_encode(array('type'=>'system', 'message'=>$ip.' disconnected')));
			send_message($response);
		}
	}
}
socket_close($socket);
// close the listening socket : Server Close
// closes the resource socket $socket



function send_message($msg)
{
	global $clients;
	// the $clients variable which is present in global perspective is used here
	foreach($clients as $changed_socket)
	{
		@socket_write($changed_socket,$msg,strlen($msg));
		// @ is used to supress the errors or warning 
		// i think i saw the suppression level depends on php.ini config
	}
	return true;
}


//Unmask incoming framed message
function unmask($text) {
	//Got: |üâû╨K█⌡▒?|9
	//Did: |cat|3
	$length = ord($text[1]) & 127; // neglect the first char : ü and get second char and mask till 7 Significants
	// else condition means length of text is <=125 
	// if 126 ...length of dicypher will be from 126 to 65535 inclusive on both sides
	// if 127 ...length of dicypher >= 65536
	if($length == 126) {
		$masks = substr($text, 4, 4);  // substr of start , length 
		$data = substr($text, 8);
		// $text 0  is useless text : 129 
		
		// $text 1  is <= 125 or 126 or 127
		// $text 2 , 3 , 4 , 5 is masks and rest is data
		
		// $text 1 , 2 , 3 is to hold length of 126 to 65535 inclusive 		
		// $text 4 , 5 , 6 , 7 is masks and rest is data
		
		// $text 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , holds the >= 65536
		// $text 10 , 11 , 12 , 13 hold masks and rest is data
		
	}
	elseif($length == 127) {
		$masks = substr($text, 10, 4);
		$data = substr($text, 14);
	}
	else {
		$masks = substr($text, 2, 4);
		$data = substr($text, 6);
	}
	$text = "";
	for ($i = 0; $i < strlen($data); ++$i) {
		$text .= $data[$i] ^ $masks[$i%4]; // XOR function ..Logic needs to be revised
	}
	
	return $text;
	
	// Conclusion : masking of client = unmasking of server
	// and masking of server = unmasking of client 
	// masking of server here is NOT equal to unmasking of server
}

//Encode message for transfer to client.
function mask($text)
{
	$b1 = 0x80 | (0x1 & 0x0f); // 129 
	$length = strlen($text);// say cat : 3 	
	if($length <= 125) 
		$header = pack('CC', $b1, $length); // Unsigned Char , Unsigned Char 
	elseif($length > 125 && $length < 65536)
		$header = pack('CCn', $b1, 126, $length);// Unsigned Char , Unsigned Char , Unsigned INT 16 Bit ( big endian )
	elseif($length >= 65536)
		$header = pack('CCNN', $b1, 127, $length);// Unsigned Char , Unsigned Char , Unsigned INT 32 Bit ( big endian )
		// Big Endian is normal way of representing values in array 
	return $header.$text;
	// concat header to text : cyphered 
}

//handshake new client.
function perform_handshaking($receved_header,$client_conn, $host, $port)
{
	$headers = array();
	$lines = preg_split("/\r\n/", $receved_header);
	// split when regular expression \r\n is found in header 	
	foreach($lines as $line)
	{
		$line = chop($line); // right trim 
		//http://support.sas.com/documentation/cdl/en/lrdict/64316/HTML/default/viewer.htm#a003288497.htm
		// for wildcards regex
		// \A only at starting of the string
		// \S non space and non new line and non new vertical align
		// \z only at the end of the string
		if(preg_match('/\A(\S+): (.*)\z/', $line, $matches))
		{
			//"Upgrade: websocket\r\n" .
			//"Connection: Upgrade\r\n" .
			// $matches are all possible matches 
			// take line 'Upgrade: websocket'
			// matches = { Upgrade: websocket , Upgrade , websocket }
			// all three satisfy matching ending criteria
			$headers[$matches[1]] = $matches[2];
		}
	}

	$secKey = $headers['Sec-WebSocket-Key'];
	// 24 Letters key that is different for each reload of client page
	
	$secAccept = base64_encode(pack('H*', sha1($secKey . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')));
	// SHA1 is secure hash algorithm that converts input string into 40 byte hexadecimal hash key
	// secKey = 16 byte , base64 encode string
    // magic string 258EAFA5-E914-47DA-95CA-C5AB0DC85B11 
	// putting them both in sha1 gives 40-character hexadecimal number    
	// string(24) "K7NpJ/M+KpE5EAysxJoXkQ==" ( seckey )
	// string(40) "4c9e291e4dbb3c547a1dbeb815fc99b2caefe389" ( after doing sha1 with magic word )
	// string(20) "3¥♂e;ƒ∟p♀ö9↓Ä├[╘Ö!~0" ( after pack ( 'H*' , <on-sha1-string> )  )
	// pack ... will convert data into binary ...in this case into Hexadecimal high nybble first 
	// string(28) "SP3icv53IUm70cNjBWwFmj1hUgU=" (after base encode 64 for another test result )
	// all are run for different times
	

	
	//hand shaking header
	// The response header for client to accept 
	$upgrade  = "HTTP/1.1 101 Web Socket Protocol Handshake\r\n" .
	"Upgrade: websocket\r\n" .
	"Connection: Upgrade\r\n" .
	"WebSocket-Origin: $host\r\n" .
	"WebSocket-Location: ws://$host:$port/demo/shout.php\r\n".
	"Sec-WebSocket-Accept:$secAccept\r\n\r\n";
	
	socket_write($client_conn,$upgrade,strlen($upgrade));
	// client socket is sent the response header 
	// SOCKET , BUFFER , LENGTH OF BUFFER
}
